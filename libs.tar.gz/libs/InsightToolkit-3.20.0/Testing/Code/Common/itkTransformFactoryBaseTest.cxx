/*=========================================================================

  Program:   Insight Segmentation & Registration Toolkit
  Module:    $RCSfile: itkTransformFactoryBaseTest.cxx,v $
  Language:  C++
  Date:      $Date: 2010-07-06 13:35:05 $
  Version:   $Revision: 1.1 $

  Copyright (c) Insight Software Consortium. All rights reserved.
  See ITKCopyright.txt or http://www.itk.org/HTML/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even 
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR 
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
#if defined(_MSC_VER)
#pragma warning ( disable : 4786 )
#endif

#include <iostream>
#include <string.h>
#include "itkVersion.h"
#include "itkTransformFactoryBase.h"

int itkTransformFactoryBaseTest (int, char*[])
{
  // Call register default transforms
  itk::TransformFactoryBase::RegisterDefaultTransforms();
  
  // Print out the names of all the registered transforms
  std::list<std::string> names = itk::TransformFactoryBase::GetFactory()->GetClassOverrideWithNames();
  
  // create the list of default transforms
  std::list<std::string> defaultTransforms;
  defaultTransforms.push_back("AffineTransform_double_2_2");
  defaultTransforms.push_back("AffineTransform_double_3_3");
  defaultTransforms.push_back("BSplineDeformableTransform_double_2_2");
  defaultTransforms.push_back("BSplineDeformableTransform_double_3_3");
  defaultTransforms.push_back("CenteredAffineTransform_double_2_2");
  defaultTransforms.push_back("CenteredAffineTransform_double_3_3");
  defaultTransforms.push_back("CenteredEuler3DTransform_double_3_3");
  defaultTransforms.push_back("CenteredRigid2DTransform_double_2_2");
  defaultTransforms.push_back("CenteredSimilarity2DTransform_double_2_2");
  defaultTransforms.push_back("Euler2DTransform_double_2_2");
  defaultTransforms.push_back("Euler3DTransform_double_3_3");
  defaultTransforms.push_back("FixedCenterOfRotationAffineTransform_double_3_3");
  defaultTransforms.push_back("IdentityTransform_double_2_2");
  defaultTransforms.push_back("IdentityTransform_double_3_3");
  defaultTransforms.push_back("QuaternionRigidTransform_double_3_3");
  defaultTransforms.push_back("Rigid2DTransform_double_2_2");
  defaultTransforms.push_back("Rigid3DPerspectiveTransform_double_3_2");
  defaultTransforms.push_back("Rigid3DTransform_double_3_3");
  defaultTransforms.push_back("ScalableAffineTransform_double_3_3");
  defaultTransforms.push_back("ScaleLogarithmicTransform_double_3_3");
  defaultTransforms.push_back("ScaleSkewVersor3DTransform_double_3_3");
  defaultTransforms.push_back("ScaleTransform_double_2_2");
  defaultTransforms.push_back("ScaleTransform_double_2_2");  // This is in twice since that's the way it is in TransformFactoryBase
  defaultTransforms.push_back("ScaleTransform_double_3_3");
  defaultTransforms.push_back("TranslationTransform_double_3_3");
  defaultTransforms.push_back("VersorRigid3DTransform_double_3_3");
  defaultTransforms.push_back("VersorTransform_double_3_3");
  defaultTransforms.push_back("Similarity2DTransform_double_2_2");
  
  defaultTransforms.push_back("AffineTransform_float_2_2");
  defaultTransforms.push_back("AffineTransform_float_3_3");
  defaultTransforms.push_back("BSplineDeformableTransform_float_2_2");
  defaultTransforms.push_back("BSplineDeformableTransform_float_3_3");
  defaultTransforms.push_back("CenteredAffineTransform_float_2_2");
  defaultTransforms.push_back("CenteredAffineTransform_float_3_3");
  defaultTransforms.push_back("CenteredEuler3DTransform_float_3_3");
  defaultTransforms.push_back("CenteredRigid2DTransform_float_2_2");
  defaultTransforms.push_back("CenteredSimilarity2DTransform_float_2_2");
  defaultTransforms.push_back("Euler2DTransform_float_2_2");
  defaultTransforms.push_back("Euler3DTransform_float_3_3");
  defaultTransforms.push_back("FixedCenterOfRotationAffineTransform_float_3_3");
  defaultTransforms.push_back("IdentityTransform_float_2_2");
  defaultTransforms.push_back("IdentityTransform_float_3_3");
  defaultTransforms.push_back("QuaternionRigidTransform_float_3_3");
  defaultTransforms.push_back("Rigid2DTransform_float_2_2");
  defaultTransforms.push_back("Rigid3DPerspectiveTransform_float_3_2");
  defaultTransforms.push_back("Rigid3DTransform_float_3_3");
  defaultTransforms.push_back("ScalableAffineTransform_float_3_3");
  defaultTransforms.push_back("ScaleLogarithmicTransform_float_3_3");
  defaultTransforms.push_back("ScaleSkewVersor3DTransform_float_3_3");
  defaultTransforms.push_back("ScaleTransform_float_2_2");
  defaultTransforms.push_back("ScaleTransform_float_2_2");  // This is in twice since that's the way it is in TransformFactoryBase
  defaultTransforms.push_back("ScaleTransform_float_3_3");
  defaultTransforms.push_back("TranslationTransform_float_3_3");
  defaultTransforms.push_back("VersorRigid3DTransform_float_3_3");
  defaultTransforms.push_back("VersorTransform_float_3_3");
  defaultTransforms.push_back("Similarity2DTransform_float_2_2");
  
  // check to make sure that all default transforms have been registered
  defaultTransforms.sort();
  names.sort();
  std::list<std::string>::iterator namesIt;
  std::list<std::string>::iterator defaultsIt;
  for (namesIt = names.begin(), defaultsIt = defaultTransforms.begin(); 
       namesIt != names.end(), defaultsIt != defaultTransforms.end();
       namesIt++, defaultsIt++)
    {
    if (strcmp((*namesIt).c_str(), (*defaultsIt).c_str()) != 0)
      {
      std::cout << "[FAILED] " << *defaultsIt << " not registered properly with defaults" << std::endl;
      return EXIT_FAILURE;
      }
    else
      {
      std::cout << "[SUCCESS] " << *defaultsIt << " registered properly" << std::endl;
      }
    }
  
  // test other methods
  itk::TransformFactoryBase::Pointer base = itk::TransformFactoryBase::New();
  const char* itkVersion = base->GetITKSourceVersion();
  const char* description = base->GetDescription();
  const char* type = base->GetNameOfClass();
  if (strcmp(itkVersion, ITK_SOURCE_VERSION) != 0)
    {
    std::cout << "[FAILED] Did not report version correctly" << std::endl;
    }
  else
    {
    std::cout << "[SUCCESS] Reported version correctly as " << itkVersion << std::endl;
    }
  if (strcmp(description, "Transform FactoryBase") != 0)
    {
    std::cout << "[FAILED] Did not report description correctly" << std::endl;
    }
  else
    {
    std::cout << "[SUCCESS] Reported description correctly as " << description << std::endl;
    }
  if (strcmp(type, "TransformFactoryBase") != 0)
    {
    std::cout << "[FAILED] Did not report type correctly" << std::endl;
    }
  else
    {
    std::cout << "[SUCCESS] Reported type correctly as " << type << std::endl;
    }
  
  // return successfully
  return EXIT_SUCCESS;

}
