Accuracy.cxx 
This is the code used to process volumes and make accuracy calculations.
Requires a parameter file as its only argument.  See the ParameterFiles directory
for details.

GenerateGoldStandard.txt
This is the code used to create the ground truth volumes used in the study.
Requires a parameter file as its only argument.  See the ParameterFiles directory
for details.



