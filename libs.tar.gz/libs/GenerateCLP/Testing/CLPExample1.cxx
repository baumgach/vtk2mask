#include "CLPExample1CLP.h"

int main (int argc, char *argv[])
{
  PARSE_ARGS;
  return 0;
}

