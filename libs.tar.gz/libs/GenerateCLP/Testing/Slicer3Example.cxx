#include "Slicer3ExampleCLP.h"

int main (int argc, char *argv[])
{
  PARSE_ARGS;
  return 0;
}

